from data_ingestion.scraper import scrape_website
from query_handling.query_processor import QueryProcessor

def main():
    # Scrape content from the Stanford website (or any website)
    url = "https://www.stanford.edu/"
    scraped_data = scrape_website(url)

    # Initialize the QueryProcessor with the scraped data
    query_processor = QueryProcessor(scraped_data)

    # Example: User enters a query
    query = input("Enter your query: ")

    # Get search results
    results = query_processor.search(query)

    # Display the results
    if results:
        print(f"\nFound {len(results)} result(s) for '{query}':\n")
        for result in results:
            print(f"Title: {result['title']}")
            print(f"URL: {result['url']}")
            print(f"Content: {result['content'][:500]}...")  # Show a snippet of the content
            print("\n" + "-"*50 + "\n")
    else:
        print(f"No results found for '{query}'.")

if __name__ == "__main__":
    main()
