import requests
from bs4 import BeautifulSoup

def scrape_website(url):
    """Scrapes the website and returns the title and body content."""
    content_data = []  # List to store fetched content
    try:
        response = requests.get(url)
        soup = BeautifulSoup(response.text, 'html.parser')

        # Store the title of the page and the text body
        title = soup.title.string if soup.title else 'No title'
        body_text = ' '.join([p.get_text() for p in soup.find_all('p')])

        content_data.append({
            'url': url,
            'title': title,
            'content': body_text
        })

        print(f"Successfully fetched the content from {url}")
    except Exception as e:
        print(f"Error fetching {url}: {e}")
    
    return content_data
