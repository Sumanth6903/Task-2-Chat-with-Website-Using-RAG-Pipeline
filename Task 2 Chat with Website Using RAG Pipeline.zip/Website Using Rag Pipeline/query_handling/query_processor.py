import re

class QueryProcessor:
    def __init__(self, data):
        """Initializes with the scraped content."""
        self.data = data  # The scraped content (list of dictionaries)

    def search(self, query):
        """Searches for the query in the content."""
        query = query.lower()
        results = []

        for item in self.data:
            title = item['title'].lower()
            content = item['content'].lower()

            # Simple keyword match in both title and content
            if re.search(query, title) or re.search(query, content):
                results.append({
                    'url': item['url'],
                    'title': item['title'],
                    'content': item['content']
                })
        
        return results
